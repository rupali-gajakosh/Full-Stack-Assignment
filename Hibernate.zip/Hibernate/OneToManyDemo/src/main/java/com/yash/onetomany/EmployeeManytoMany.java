package com.yash.onetomany;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.LogicalExpression;
import org.hibernate.criterion.Restrictions;
 
// Class
public class EmployeeManytoMany {
 
    // Class data member
    private static SessionFactory factory;
 
    // Main driver method
    public static void main(String[] args)
    {
 
        // Try block to check for exceptions
        try {
 
            factory = new Configuration()
                          .configure()
                          .buildSessionFactory();
        }
 
        // Catch block to handle exceptions
        catch (Throwable ex) {
 
            // Display command when exception occurred
            System.err.println(
                "Failed to create sessionFactory object."
                + ex);
            throw new ExceptionInInitializerError(ex);
        }
 
        EmployeeManytoMany EmployeeObject
            = new EmployeeManytoMany();
 
        // Let us have a set of skills for few employees
        HashSet skillSets = new HashSet();
 
        skillSets.add(new SkillsetData("Java"));
        skillSets.add(new SkillsetData("Python"));
        skillSets.add(new SkillsetData("R Programming"));
 
        HashSet databaseSkillSets = new HashSet();
 
        databaseSkillSets.add(new SkillsetData("MySQL"));
        databaseSkillSets.add(
            new SkillsetData("SQL Server"));
        databaseSkillSets.add(new SkillsetData("MongoDB"));
 
        HashSet generalSkillset = new HashSet();
        generalSkillset.add(skillSets);
        generalSkillset.add(databaseSkillSets);
 
        // Add few employee records in database
        Integer empID1 = EmployeeObject.addEmployee(
            "GeekA", "GeekA", 100000, skillSets);
        Integer empID2 = EmployeeObject.addEmployee(
            "GeekB", "GeekB", 50000, databaseSkillSets);
        Integer empID3 = EmployeeObject.addEmployee(
            "GeekC", "GeekC", 50000, skillSets);
    }
 
    /* Method to CREATE an employee in the database. Inserts
data in
geekEmployeeData, SkillsetData and geekEmployeeSkill table
*/
    public Integer addEmployee(String fname, String lname,
                               int salary, Set skillSets)
    {
        Session session = factory.openSession();
        Transaction tx = null;
        Integer employeeID = null;
 
        try {
            tx = session.beginTransaction();
            EmployeeData employee
                = new EmployeeData(fname, lname,
                                       salary);
            employee.setSkillSets(skillSets);
            employeeID = (Integer)session.save(employee);
            tx.commit();
        }
        catch (HibernateException e) {
            if (tx != null)
                tx.rollback();
            e.printStackTrace();
        }
 
        // finally block
        finally {
 
            // Closing the sessions
            // using close() method
            session.close();
        }
 
        return employeeID;
    }
