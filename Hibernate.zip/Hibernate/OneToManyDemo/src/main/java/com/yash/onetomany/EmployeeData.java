package com.yash.onetomany;

public class EmployeeData {
	 private int id;
	 private String firstName;
	 private String lastName;
	 private int salary;
	 private Set skillSets;
	 public Set getSkillSets() 
	 {
		 return skillSets;
		 }
	 
	 public void setSkillSets(Set skillSets)
	    {
	 
	    
	        this.skillSets = skillSets;
	    }
	 
	    // Constructor 1
	    public EmployeeData() {}
	 
	    // Constructor 2
	    public EmployeeData(String firstName, String lastName, int salary)
	    {
	 
	        // This keyword refers to current instance itself
	        this.firstName = firstName;
	        this.lastName = lastName;
	        this.salary = salary;
	    }
	 
	    // Getter  and Setters
	 
	    public int getId() { return id; }
	    public void setId(int id) { this.id = id; }
	    public String getFirstName() { return firstName; }
	    public void setFirstName(String firstName)
	    {
	        this.firstName = firstName;
	    }
	    public String getLastName() { return lastName; }
	    public void setLastName(String lastName)
	    {
	        this.lastName = lastName;
	    }
	    public int getSalary() { return salary; }
	    public void setSalary(int salary)
	    {
	        this.salary = salary;
	    }

}
