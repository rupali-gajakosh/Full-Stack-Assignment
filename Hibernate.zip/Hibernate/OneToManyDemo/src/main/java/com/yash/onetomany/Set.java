package com.yash.onetomany;

import java.util.Iterator;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.mapping.List;

public class Set {
	
	public void listEmployeeData()
	{

		Session session = factory.openSession();
		Transaction tx = null;

		// Try block to check for exceptions
		try {
			tx = session.beginTransaction();

			Criteria geekEmployeeCriteria
				= session.createCriteria(
					EmployeeData.class);
			List geekEmployeeList = geekEmployeeCriteria.list();

			for (Iterator iterator
				= geekEmployeeList.iterator();
				iterator.hasNext();) {

			EmployeeData employeeData
					= (EmployeeData)iterator.next();
				System.out.print("First Name: "
								+ employeeData.getFirstName());
				System.out.print(" Last Name: "
								+ employeeData.getLastName());
				System.out.println(" Salary: "
								+ employeeData.getSalary());

				// As we have used Set to store data, during
				// display
				// also we need to use the set

				// Iterate and get the skills one by one.
				// An employee may have more than 1 skill
				Set skillSets = employeeData.getSkillSets();

				for (Iterator it = skillSets.iterator();
					it.hasNext();) {
					SkillsetData skillName
						= (SkillsetData)it.next();
					System.out.println(
						"SkillName: "
						+ skillName.getSkillName());
				}
			}

			tx.commit();
		}

		// Catch block to handle exceptions
		catch (HibernateException e) {

			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		}

		// finally block which will execute for sure
		finally {

			// Closing all sessions
			// using close() method
			session.close();
		}
	}


}
