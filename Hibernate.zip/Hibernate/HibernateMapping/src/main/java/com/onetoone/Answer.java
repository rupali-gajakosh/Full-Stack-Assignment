package com.onetoone;
import javax.persistence.Entity;
import javax.persistence.Entity;
import javax.persistence.ID;
@Entity
public class Answer {
	@ID
	@Column(name="answerID")
	private int answerID;
	private String answer;

	

}
