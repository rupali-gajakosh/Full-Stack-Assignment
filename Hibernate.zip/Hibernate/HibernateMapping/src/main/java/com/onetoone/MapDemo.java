package com.onetoone;


import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;


public class MapDemo {
	public static void main(String[] args)
	{
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory factory=cfg.buildSesionFactory();
		
		Question q1=new Question();
		q1.setQuestionID(1212);
		q1.setQuestion("What is java ?");
		
		Answer answer=new Answer();
		q1.setAnswerID(343);
		q1.setAnswer("Java is Programming language");
		q1.setAnswer(answer);
		
		factory.close();
	}

}
