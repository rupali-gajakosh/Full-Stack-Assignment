package com.onetoone;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ID;
public class Question {
	@ID
	@
	private int questionID;
	private String question;
	

}
