import React, {Component} from 'react';



class Content2 extends React.Component

{

render()

{

    return(

        <div>

            <h3 class="login2">REGISTRATION</h3>
            <fieldset >
            <form action="">
            <label>First Name* </label>
            <input type="text" name="firstname" size="15"></input>
            <br></br>
            <label>Last Name* </label>
            <input type="text" name="lastname" size="15"></input><br></br>
            <label>Password* </label>
            <input type="password" name="password" size="15"></input><br></br>
            <label><b> Gender</b> </label>
            <br></br>
            <input type="radio" id="male" name="gender" value="male"/>
            <label for="male">Male</label><br></br>
           <input type="radio" id="female" name="gender" value="female" />
           <label for="female">Female</label><br></br>
           <input type="radio" id="other" name="gender" value="other"/>
           <label for="other">Other</label><br></br>
           <h4><b>Hobbies</b></h4>
           <input type="checkbox" id="dancing" name="Dancing" value="dancing"/>
  <label for="vehicle1"> Dancing</label><br></br>
  <input type="checkbox" id="singing" name="Singing" value="singing"/>
  <label for="vehicle2"> Singing</label><br></br>
  <input type="checkbox" id="reading" name="Reading" value="reading"/>
  <label for="vehicle3"> Reading</label><br></br>
  <input type="checkbox" id="travelling" name="Travelling" value="travelling"/>
  <label for="vehicle3"> Travelling</label><br></br>
            <input  type="button" value="submit"/>
            </form>
           </fieldset>

        </div>

    );

}



}

export default Content2;