import React,{Component} from 'react';



class Bigimage extends React.Component



{



    render()



    {



        return(<div>



           

             <img class="image2" src="images1.png"></img>

        </div>);



    }



}



export default Bigimage;