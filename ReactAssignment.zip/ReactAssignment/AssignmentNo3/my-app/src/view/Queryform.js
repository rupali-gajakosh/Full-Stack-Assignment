import React, {Component} from 'react';

class Queryform extends React.Component

{

render()

{

    return(

        <div>

            <h3>QueryForm</h3>
            <fieldset>



                <form>

                <label>First Name:</label>

                 <input type="text" name="fname" size="18"/>

                 <label>Last Name:</label>

                 <input type="text" name="lname" size="18"/>

                 <br></br>

                 <input type="button" value="submit"/>

                </form>

            </fieldset>

        </div>

    );

}



}

export default Queryform;