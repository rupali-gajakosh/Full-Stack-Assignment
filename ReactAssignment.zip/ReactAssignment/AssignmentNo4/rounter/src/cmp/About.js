import React,{Component} from 'react';
class About extends React.Component
{
render()
{

 return(<div>
<h1>About</h1>
 <h2>hello</h2>
  </div>);
         }
}

export default About;