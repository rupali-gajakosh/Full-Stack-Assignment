import React,{Component} from 'react';





class Home extends React.Component





{





    render()





    {





        return(<div>





            <h1>Home</h1>



            <p>Welcome to Home page.</p>
 
        <p>Yash Technologies.</p>





        </div>);





    }





}





export default Home;