package mypackage;
public class Start{
	public void display(){
		System.out.println("In display method of Start Class");
	}
}