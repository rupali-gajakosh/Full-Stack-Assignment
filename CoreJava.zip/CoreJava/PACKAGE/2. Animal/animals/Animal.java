package animals;
public interface Animal{
		public void move();
		public void eat();
		public void sleep();
}