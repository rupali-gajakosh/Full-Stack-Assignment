package com.automobile.twowheeler;

import com.automobile.Vehicle;

// Hero getSpeed(), void radio

public class Hero extends Vehicle{
	// Instance variable
	private String modelName;
	private String registration;
	private String OwnerName;
	
	// Constructor
	public Hero(String modelName, String registration, String OwnerName){
		this.modelName = modelName;
		this.registration = registration;
		this.OwnerName = OwnerName;
	}
	
	
	public int getSpeed(){
		return 100;
	}
	
	public void radio(){
		System.out.println("Radio is present");
	}
	public String getModelName(){
		return this.modelName;
	};
	
	public String getRegistration(){
		return this.registration;
	}
	
	public String getOwnerName(){
		return this.OwnerName;
	}
}