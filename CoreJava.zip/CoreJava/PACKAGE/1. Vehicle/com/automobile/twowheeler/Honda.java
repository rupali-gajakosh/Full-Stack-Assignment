package com.automobile.twowheeler;

import com.automobile.Vehicle;

public class Honda extends Vehicle{
	private String modelName;
	private String registration;
	private String OwnerName;
	
	public Honda(String modelName, String registration, String OwnerName){
		this.modelName = modelName;
		this.registration = registration;
		this.OwnerName = OwnerName;
	}
	
	
	//cd player, get speed
	
	public int getSpeed(){
		return 90;
	}
	
	public void cdPlayer(){
		System.out.println("CD player is present");
	}
	
	public String getModelName(){
		return this.modelName;
	};
	
	public String getRegistration(){
		return this.registration;
	}
	
	public String getOwnerName(){
		return this.OwnerName;
	}
}