package com.automobile;

public abstract class Vehicle{
// model, registration, owner
	
	
	// Correction all the methods are abstract methods
	public abstract String getModelName();
	
	public abstract String getRegistration();
	
	public abstract String getOwnerName();
}