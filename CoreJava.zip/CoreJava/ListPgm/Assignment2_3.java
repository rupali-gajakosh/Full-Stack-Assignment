import java.util.Iterator;
import java.util.TreeSet;

public class Assignment2_3 
{

	public static void main(String[] args)
	{
		TreeSet<String> set = new TreeSet<>();

		set.add("Rupali");
		set.add("Karishma");
		set.add("Shree");
		set.add("Mayuri");
		
		Iterator<String> it = set.iterator();
		String query = "disha";
		boolean result = false;
		
		while (it.hasNext())

			{
			if (it.next().equals(query)) 
			{
				result = true;
				break;
			}
		}
		
		if (result)
			System.out.println(query + " exists");
		else 
			System.out.println(query + " doesn't exist");

	}

}


-----output-----


C:\Users\rupali.gajakosh\Desktop>javac Assignment2_3.java

C:\Users\rupali.gajakosh\Desktop>java Assignment2_3
disha doesn't exist