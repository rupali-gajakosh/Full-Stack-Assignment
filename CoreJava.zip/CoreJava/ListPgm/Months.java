import java.util.Vector;
import java.util.ArrayList;
import java.util.Collection;
  
public class Months {
    public static void main(String args[])
    {
  
       
        Vector<String> vt = new Vector<String>();
		  vt.add("January ");//Adding object in arraylist    
		  vt.add("February ");    
		  vt.add("March");    
		  vt.add("April"); 
		  vt.add("May "); 
		  vt.add("June"); 
		  vt.add("July"); 
		  vt.add("August"); 
		  vt.add("September");
		  vt.add("October");
		  vt.add("November");
		  vt.add("December");		
  
        
        Collection<String> c = new ArrayList<String>();
        c.add("Jan");
        c.add("Feb");
        c.add("Mar");
        c.add("Apr");
        c.add("May");
  
       System.out.println("The Vector is: " + vt);
  
        vt.addAll(c);
		System.out.println("The new vector is: " + vt);
    }
}

----output------


C:\Users\rupali.gajakosh\Desktop>javac Months.java

C:\Users\rupali.gajakosh\Desktop>java Months
The Vector is: [January , February , March, April, May , June, July, August, September, October, November, December]
The new vector is: [January , February , March, April, May , June, July, August, September, October, November, December, Jan, Feb, Mar, Apr, May]