
import java.util.Iterator;
import java.util.Vector;

class Employee 
{
	private int id;
	private String name;
	private String address;
	private Double salary;
	
	public Employee(int id, String name, String address, Double salary) 
	{
		super();
		this.id = id;
		this.name = name;
		this.address = address;
		this.salary = salary;
	}	
	
	public int getId() 
	{
		return id;
	}

	
	public String toString() 
	{
		return "Employee [id=" + id + ", name=" + name + ", address=" + address + ", salary=" + salary + "]";
	}
}

public class Assignment4
 {

	public static void main(String[] args)
	{
		Vector<Employee> list = new Vector<>();
		
		list.add(new Employee(1014826, "Rupali", "101 Pune, India", 10000.0));
		list.add(new Employee(1014827, "Karishma", "102 Indore, India", 50000.0));
		list.add(new Employee(1014828, "Pranita", "103 Hydrabad, India", 60000.0));
		list.add(new Employee(1014829, "Sushmita", "104 Mumbai, India", 35000.0));
		
		Iterator<Employee> it = list.iterator();
		while (it.hasNext()) 
			System.out.println(it.next());
		

	}

}

------output-------------


C:\Users\rupali.gajakosh\Desktop>javac Assignment4.java

C:\Users\rupali.gajakosh\Desktop>java Assignment4
Employee [id=1014826, name=Rupali, address=101 Pune, India, salary=10000.0]
Employee [id=1014827, name=Karishma, address=102 Indore, India, salary=50000.0]
Employee [id=1014828, name=Pranita, address=103 Hydrabad, India, salary=60000.0]
Employee [id=1014829, name=Sushmita, address=104 Mumbai, India, salary=35000.0]
