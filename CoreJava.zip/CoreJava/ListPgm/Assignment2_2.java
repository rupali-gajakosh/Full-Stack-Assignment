
import java.util.HashSet;
import java.util.Iterator;

public class Assignment2_2 
{

	public static void main(String[] args) 
	{
		HashSet<String> set = new HashSet<>();
		
		set.add("Rupali");
		set.add("Rutuja");
		set.add("Priti");
		set.add("Sushmita");
		
		Iterator<String> it = set.iterator();
		while (it.hasNext())
			System.out.println(it.next());

	}

}

-----output-----


C:\Users\rupali.gajakosh\Desktop>javac Assignment2_2.java

C:\Users\rupali.gajakosh\Desktop>java Assignment2_2
Priti
Rupali
Sushmita
Rutuja