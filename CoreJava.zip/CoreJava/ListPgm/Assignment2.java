import java.util.ArrayList;
import java.util.List;
class MyArrayList<Array> extends ArrayList<Array> {
	//@Override
	public boolean add(Array e) 
	{
		if (e instanceof Integer || e instanceof Float || e instanceof Double) 
		{
			super.add(e);
			return true;
		} else 
		{
			throw new ClassCastException("Only Integer, Float and Double are supported.");
		}
	}
}
public class Assignment2 
{

	public static void main(String[] args) {
		List<Object> list = new MyArrayList<>();
		
		try {
			list.add(19);
			list.add(2.2F);
			list.add(3.14D);
		
		} catch (Exception e) 
		{
			e.printStackTrace(); //to get all name,descrip, and stackTrace
		}
		
		System.out.println(list);

	}

}

-------------output-------

C:\Users\rupali.gajakosh\Desktop>javac Assignment2.java

C:\Users\rupali.gajakosh\Desktop>java Assignment2
[19, 2.2, 3.14]