class ThisDemo3
{
	int a;
	int b;
	ThisDemo3()
	{
		this(10,35);
		System.out.println("Default Constructor\n");
	}
	ThisDemo3(int a,int b)
	{
		this.a=a;
		this.b=b;
		System.out.println("Parameterized Constructor");
	}
	public static void main(String[] args)
	{
		ThisDemo3 td=new ThisDemo3();
	}
}

------------output---------------------------------


C:\Users\rupali.gajakosh\Desktop>javac ThisDemo3.java

C:\Users\rupali.gajakosh\Desktop>java ThisDemo3
Parameterized Constructor
Default Constructor