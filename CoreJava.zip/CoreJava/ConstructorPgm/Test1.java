class ABC
{
	ABC getABC()
	{
	return this;
	
	}
	void msg()
	{
		System.out.println("Hello Every One");
	}
		
	}
	class Test1
	{
		public static void main(String args[])
		{
			new ABC().getABC().msg();
		}
	}
	
	
	
	
	-----------output------------
	
C:\Users\rupali.gajakosh>cd Desktop

C:\Users\rupali.gajakosh\Desktop>javac Test1.java

C:\Users\rupali.gajakosh\Desktop>java Test1
Hello Every One
