class ThisDemo1
{
	int a;
	int b;
	ThisDemo1(int a,int b)
{
	this.a=a;
	this.b=b;
}
void display()
{
	System.out.println("a="+ a + "b="+ b);
	
}
public static void main(String[] args)
{
	ThisDemo1 td=new ThisDemo1(10,15);
	td.display();
}
}

-----------output---------------------

C:\Users\rupali.gajakosh\Desktop>javac ThisDemo1.java

C:\Users\rupali.gajakosh\Desktop>java ThisDemo1
a=10b=15

C:\Users\rupali.gajakosh\Desktop>
