class Box
{
	double w,h,d;
	Box( double width,double height,double depth)
	{
		
		w = width;
		h = height;
		d = depth;
	}
	double volume()
	{
		double v;
		v = w*h*d;
		return v;
	}
	public static void main(String[] args)
	{
		Box bx = new Box(55.5,13.00,44.5);
		System.out.println(bx.volume());
	}
}

-------------output---------------------

C:\Users\rupali.gajakosh>cd Desktop

C:\Users\rupali.gajakosh\Desktop>javac Box.java

C:\Users\rupali.gajakosh\Desktop>java Box
32106.75
