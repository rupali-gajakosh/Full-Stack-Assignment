import java.util.*;
class patient
{
String patientName;
double height;
double weight;
patient()
{
Scanner in=new Scanner(System.in);
System.out.println("Enter your Name:");
patientName=in.nextLine();

System.out.println("Enter your height");
height=in.nextDouble();

System.out.println("Enter your weight");
weight=in.nextDouble();
}
void BMI()
{
double bmi;
bmi=(weight/(height*height))*703;
System.out.println("You entered string"+patientName);
System.out.println("You entered weight"+weight);
System.out.println("You entered height"+height);
System.out.println("You entered bmi"+bmi);

}
public static void main(String[] args)
{
patient pn=new patient();
pn.BMI();
}
}


----------output--------------

C:\Users\rupali.gajakosh\Desktop>javac patient.java

C:\Users\rupali.gajakosh\Desktop>java patient
Enter your Name:
Shruti
Enter your height
5.5
Enter your weight
45
You entered stringShruti
You entered weight45.0
You entered height5.5
You entered bmi1045.7851239669421