class ThisDemo2
{
	void dislapy()
	{
	this.show();
	System.out.println("Welcome To Yash Technologies");
	}
	void show()
	{
	System.out.println("Congratulations");
	}
	public static void main(String args[])
	{
		ThisDemo2 td=new ThisDemo2();
		td.dislapy();
	}
}


----------output------------------

C:\Users\rupali.gajakosh\Desktop>javac ThisDemo2.java

C:\Users\rupali.gajakosh\Desktop>java ThisDemo2
Congratulations
Welcome To Yash Technologies

C:\Users\rupali.gajakosh\Desktop>
