class ThisDemo

{

 int i;

 void setValue(int i)

 {

  this.i=i;

 

 }

 void show()

 {

  System.out.println(i);

 }

}

class This1

{

 public static void main(String args[])

 {

  This1 d = new This1();

  d.setValue(20);

  d.show();

 }

}