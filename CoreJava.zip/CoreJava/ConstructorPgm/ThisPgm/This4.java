class This4

{

 void y1(This4 t)

 {

  System.out.println("y1 method");

 }

 void y2()

 {

  y1(this);

 

 }

 public static void main(String[] args)

 {

  This4 t = new This4();

  t.y2();

 }

}


----------output----


D:\javapgm\ConstructorPgm\ThisPgm>javac This4.java

D:\javapgm\ConstructorPgm\ThisPgm>java This4
y1 method