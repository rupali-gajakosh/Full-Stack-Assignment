class This2

{

 void display()

 {

  System.out.println("Yash");

 }

 void show()

 {

  this.display();

 }

 public static void main(String[]args)

 {

  This2 t = new This2();

  t.show();

 }

}

------output---------


D:\javapgm\ConstructorPgm\ThisPgm>javac This2.java

D:\javapgm\ConstructorPgm\ThisPgm>java This2
Yash