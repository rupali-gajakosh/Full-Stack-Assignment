class PQR

{

PQR getPQR()

{

return this;



}

void msg()

{

System.out.println("Hello Every One");

}



}

class This6

{

public static void main(String args[])

{

new PQR().getPQR().msg();

}

}

---------output-------


D:\javapgm\ConstructorPgm\ThisPgm>javac This6.java

D:\javapgm\ConstructorPgm\ThisPgm>java This6
Hello Every One