class Demo

{

 int i;

 void setValue(int i)

 {

  this.i=i;

 

 }

 void show()

 {

  System.out.println(i);

 }

}

class This1

{

 public static void main(String args[])

 {

  Demo d = new Demo();

  d.setValue(15);

  d.show();

 }

}

---------output------


D:\javapgm\ConstructorPgm\ThisPgm>javac This1.java

D:\javapgm\ConstructorPgm\ThisPgm>java This1
15