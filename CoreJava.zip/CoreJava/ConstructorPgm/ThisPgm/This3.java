class This3

{

 This3()

 {

 System.out.println("no argument constructor");

 

 }

 This3(int a)

 {

  this();

  System.out.println("Parameterised constructor");

 }

 public static void main(String args[])

 {

  This3 t = new This3(10);

 }

}


-----------output----------


D:\javapgm\ConstructorPgm\ThisPgm>javac This3.java

D:\javapgm\ConstructorPgm\ThisPgm>java This3
no argument constructor
Parameterised constructor