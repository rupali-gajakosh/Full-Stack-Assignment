class t1

{

 t1(This5 td)

 {

  System.out.println("t1 class constructor");

 }

}

class This5

{

 void y1()

 {

  t1 t = new t1(this);

 }

 public static void main(String args[])

 {

  This5 t = new This5();

  t.y1();

 }

}

---------output-------


D:\javapgm\ConstructorPgm\ThisPgm>javac This5.java

D:\javapgm\ConstructorPgm\ThisPgm>java This5
t1 class constructor
