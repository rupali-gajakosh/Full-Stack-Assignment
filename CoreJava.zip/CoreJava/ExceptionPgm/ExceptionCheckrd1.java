import java.io.FileInputStream;
class ExceptionCheckrd1
{
	public static void main(String[] args)
	{
		try
		{
			//String s=null;
			//System.out.println(s.length());//NullPointerException
	//	FileInputStream f =new FileInputStream("D:/xyz.txt");//FileNotFoundException
		
		
			System.out.println("Hello");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
			System.out.println("Bye");
	}
		
}
