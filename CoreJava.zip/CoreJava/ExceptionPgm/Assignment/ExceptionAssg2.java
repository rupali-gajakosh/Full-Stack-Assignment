import java.util.Scanner;
public class ExceptionAssg2
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter an in integer:");
		String s=sc.nextLine();
		
		try
		{
			int x= Integer.parseInt(s);
			System.out.println("The square of the number is:" + x * x);
			System.out.println("The Work has been done sucessfully ");
			
		}
		catch(NumberFormatException e)
		{
			System.out.println("Entered input is not a valid format for an integer");
		}
		sc.close();
	}
}

------output-----

C:\Users\rupali.gajakosh\Desktop>javac  ExceptionAssg2.java

C:\Users\rupali.gajakosh\Desktop>java  ExceptionAssg2
Enter an in integer:
yash
Entered input is not a valid format for an integer