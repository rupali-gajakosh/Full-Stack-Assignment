import java.util.InputMismatchException;
import java.util.Scanner;

public class ExceptionAssg6
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the number of the element in the array:");
		int n=sc.nextInt();
		
		int[] arr=new int[n];
		
		System.out.println("Enter the element in the array:");
		try
		{
			for(int i=0;i<n;i++)
				arr[i]=sc.nextInt();
			
			System.out.println("Enter the index of the array element you want to access");
			
			int index=sc.nextInt();
			System.out.println("The array element at index"+ index + " = "+ arr[index]);
			System .out.println("The array element successfully accessed");
			
		}catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("java.lang.ArrayIndexOutOfBoundsException");
		}catch(InputMismatchException e)
		{
			System.out.println("java.util.InputMismatchException");
		}
		sc.close();
	}
}


---------output------------


C:\Users\rupali.gajakosh\Desktop>javac ExceptionAssg6.java

C:\Users\rupali.gajakosh\Desktop>java ExceptionAssg6
Enter the number of the element in the array:
2
Enter the element in the array:
30
J
java.util.InputMismatchException