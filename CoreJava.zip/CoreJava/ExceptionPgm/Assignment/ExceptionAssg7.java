import java.util.Scanner;
 public class ExceptionAssg7
 {
	 public static void main(String[] args)
	 {
		 Scanner sc=new Scanner(System.in);
		 
		 int a=sc.nextInt();
		 int b=sc.nextInt();
		 
		 try
		 {
			 double r=division(a,b);
			 System.out.println(r);
			 
		 }catch(ArithmeticException e)
		 {
			 System.out.println(e.getMessage());
		 }
		 sc.close();
	 }
	 public static double division(int a,int b)throws ArithmeticException
	 {
		 return a/b;
	 }
 }
 
 ------output-----------
 
 
C:\Users\rupali.gajakosh\Desktop>javac ExceptionAssg7.java

C:\Users\rupali.gajakosh\Desktop>java ExceptionAssg7
12
10
1.0