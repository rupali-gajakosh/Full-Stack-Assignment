abstract class AnonymousInner
{
	public abstract void show(); 
}
 public class AnonymousInner1
	{
		public static void main(String args[])
		{
		AnonymousInner in=new AnonymousInner()
		{
		 public void show()
		{
			System.out.println("This is an example of anonymous inner class");
		}
	 };
	 in.show();
	}
}

-----output---


C:\Users\rupali.gajakosh\Desktop>javac AnonymousInner1.java

C:\Users\rupali.gajakosh\Desktop>java AnonymousInner1
This is an example of anonymous inner class
