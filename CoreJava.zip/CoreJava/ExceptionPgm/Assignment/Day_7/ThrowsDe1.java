import java.io.*;  
class Throw
{  
 void method()throws IOException
 {  
  throw new IOException("System Error");  
 }  
}  
public class ThrowsDe1
{  
   public static void main(String args[])
   {  
    try
	{  
    Throw t=new Throw();  
     t.method();  
    }catch(Exception e)
	{
	System.out.println("exception handled carefully");
	}     
  
    System.out.println("Hello normal");  
  }  
}



----output---


C:\Users\rupali.gajakosh\Desktop>javac ThrowsDe1.java

C:\Users\rupali.gajakosh\Desktop>java ThrowsDe1
exception handled carefully
Hello normal