class Outer
{
	static String s="Rupali";
   void show1()
   {
      System.out.println("Hello outer method");
   }
    static class Inner
   {
	    void show()
   {
	   System.out.println("Inner show Name= " + s);
   }
   }
 }
 public class NestedClassCase3
 {
	 public static void main(String args[])
	 {
		 Outer o=new Outer();
		 o.show1(); 
		 Outer.Inner oi=new Outer.Inner();
		 oi.show();
	 }
 }
 
----output----------


C:\Users\rupali.gajakosh\Desktop>java NestedClassCase3
Hello outer method
Inner show Name= Rupali