class Outer
{
class Inner
{
 void show()
 {
 System.out.println("hello yash team");
 }
}
}

public class InnerDemo
{
public static void main(String[] args)
{
	Outer.Inner in=new Outer().new Inner();
	//Outer.Inner oi=o.new Inner();
	in.show();
}
}