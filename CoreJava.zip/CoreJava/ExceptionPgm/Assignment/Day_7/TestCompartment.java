import java.util.Random;

	abstract class Compartment
	{
	public abstract String notice();
	}
	class FirstClass extends Compartment
	{
	public String notice()
	{
	return "You are in First Class Compartment";
	}
	}
	class Ladies extends Compartment
	{
	public String notice()
	{
	return "You are in Ladies Compartment";
	}
	}
	class General extends Compartment
	{
	public String notice()
	{
	return "You are in General Compartment";
	}
	}
	class Luggage extends Compartment
	{
	public String notice()
	{
	return "You are in Laggage Compartment";
	}
	}
	public class TestCompartment
	{
	public static void main(String[] args)
	{
	Compartment[] c=new Compartment[10];

	Random r=new Random();

	for(int i=0;i<10;i++)
	{
	int rNum==r.nextInt((4-1)+1)+1;

	if(rNum==1)
	c[i]=new Luggage();
	else if(rNum==2)
	c[i]=new Ladies();
	else if(rNum==3)
	c[i]=new General();
	else if(rNum==4)
	c[i]=new FirstClass();

	System.out.println(c[i].notice());

	}
	
}