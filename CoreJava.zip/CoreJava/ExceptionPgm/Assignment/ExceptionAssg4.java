import java.util.Scanner;
import java.util.InputMismatchException;
 public class ExceptionAssg4
 
 {
	 public static void main(String[] args)
	 {
	 Scanner sc=new Scanner(System.in);
	 System.out.println("Enter the number of element");
	 int n=sc.nextInt();
	 int[] arr=new int[n];
	 System.out.println("Enter the element in the array:");
	 try
	 {
		 for(int i=0;i<n;i++)
			 arr[i]=sc.nextInt();
		 System.out.println("Enter the index of array element you want to access:");
		 
		 
		 int index =sc.nextInt();
		 System.out.println("The Array element at index:" + index + "=" +arr[index]);
		 System.out.println("The array element successfully accessed:");
	 
	 }
	 catch(ArrayIndexOutOfBoundsException e)
	 {
		 System.out.println("java.lang.ArrayIndexOutOfBoundsException");
	 }
	 catch(InputMismatchException e)
	 {
		 System.out.println("java.util.InputMismatchException");
	 }
	 sc.close();
	 }
 }
 
 
 -------output---------
 
C:\Users\rupali.gajakosh\Desktop>javac  ExceptionAssg4.java

C:\Users\rupali.gajakosh\Desktop>java  ExceptionAssg4
Enter the number of element
2
Enter the element in the array:
20
90
Enter the index of array element you want to access:
6
java.lang.ArrayIndexOutOfBoundsException