import java.util.Scanner;
public class ArithmaticAssg
{
	public static void main(String[] args)
	{ 
	Scanner sc=new Scanner(System.in);
	try
	{
		System.out.println("Enter the two nos:");
		int a=sc.nextInt();
		int b=sc.nextInt();
		int quotient=a/b;
		System.out.println("The quotient of " +a+" / "+b+" ="+quotient);
		
	}
	catch(ArithmeticException e)
	{
		System.out.println(e.getMessage()+"caught");
	
	}
	finally 
	{
		System.out.println("Inside finally block");
	}
	sc.close();
	}
}

-----output----------


C:\Users\rupali.gajakosh\Desktop>javac ArithmaticAssg.java

C:\Users\rupali.gajakosh\Desktop>java ArithmaticAssg
Enter the two nos:
5
2
The quotient of 5 / 2 =2
Inside finally block
