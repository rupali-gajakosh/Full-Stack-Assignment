class ExceptionDemo
{
public static void main(String[] args)
{
	System.out.print("Yash");
	System.out.println("Technologies");
	System.out.println("Jaymae");
	System.out.println("Bye");
}
}