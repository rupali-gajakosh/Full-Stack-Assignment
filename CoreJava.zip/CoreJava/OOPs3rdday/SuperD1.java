class AccountBal
{
	int s=25000;
}
class SuperD1 extends AccountBal
{
	int s=35000;
	void display(int s)
	{
		
		System.out.println(s);
		System.out.println(this.s);
		System.out.println(super.s);
		
	}
	public static void main(String[] args)
	{
		SuperD1 sd=new SuperD1();
		sd.display(30000);
	}
}

------output--------

C:\Users\rupali.gajakosh\Desktop>javac SuperD1.java

C:\Users\rupali.gajakosh\Desktop>java SuperD1
30000
35000
25000
