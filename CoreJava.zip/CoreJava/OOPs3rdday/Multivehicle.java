interface car
{ 
	
	void distance();

}
interface bike
{
	
	void speed();
}
class Multivehicle implements car,bike
{
	public void distance()
	{
		System.out.println("Distance Travelled in 125 km");
	}
	public void speed()
	{
		System.out.println("speed is 35km per hr");
	}
	public static void main(String[] args)
	{
		Multivehicle mv=new Multivehicle();
		mv.speed();
		mv.distance();
		
	}	
	
}


---------output------------------------
C:\Users\rupali.gajakosh\Desktop>javac Multivehicle.java

C:\Users\rupali.gajakosh\Desktop>java Multivehicle
speed is 35km per hr
Distance Travelled in 125 km
