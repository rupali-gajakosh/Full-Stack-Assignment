class Account
{
	Account()
	{
		System.out.println(" Saving account ");
	}
}
class SuperDemo3 extends Account
{
	SuperDemo3()
	{
		super();
		System.out.println("  Current account");
		
	}
	public static void main(String[] args)
	{
		SuperDemo3 sd=new SuperDemo3();
	}
}

----output--------

C:\Users\rupali.gajakosh\Desktop>javac SuperDemo3.java

C:\Users\rupali.gajakosh\Desktop>java SuperDemo3
 Saving account
  Current account
