class Account
{
	void display()
	{
		System.out.println(" Saving account ");
	}
}
class SuperDemo2 extends Account
{
	void display()
	{
		
		System.out.println("Current account");
		
	}
	void show ()
	{
	display();
	super.display();
	}
	public static void main(String[] args)
	{
		SuperDemo2 sd=new SuperDemo2();
		sd.show();
	}
}

------output-----


C:\Users\rupali.gajakosh\Desktop>javac SuperDemo2.java

C:\Users\rupali.gajakosh\Desktop>java SuperDemo2
Current account
 Saving account