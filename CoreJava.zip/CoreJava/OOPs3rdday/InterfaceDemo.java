interface A1
{
	public abstract void show();
	public static final int a=20;
}
		class InterfaceDemo implements A1
		{
			public void show()
			{
				System.out.println("In Demo class ");
			}
			public static void main(String args[])
			{
				InterfaceDemo id=new InterfaceDemo();
				id.show();
			}
		}
	
-----output------------

C:\Users\rupali.gajakosh\Desktop>javac  InterfaceDemo.java

C:\Users\rupali.gajakosh\Desktop>java  InterfaceDemo
In Demo class
