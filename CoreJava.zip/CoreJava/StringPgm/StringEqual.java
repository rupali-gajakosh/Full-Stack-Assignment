class StringEqual

{

 public static void main(String args[])

 {

 String s = "Hello Rupali";

  String s1 = "Hello Rupali";

 String s2 = new String("I am busy");

 




  System.out.println(s.equals(s1));

   System.out.println(s.equals(s2));

 }

}

-----output-------


D:\javapgm\StringPgm>javac StringEqual.java

D:\javapgm\StringPgm>java StringEqual
true
false