class StringTrim

{

 public static void main(String args[])

 {

 String s = " Welcome to the Yash Technologies  ";



 System.out.println(s.trim());



 

 s = "Hello yash Technology";

  System.out.println(s.trim());

 }

}

-------output-----------


D:\javapgm\StringPgm>javac StringTrim.java

D:\javapgm\StringPgm>java StringTrim
Welcome to the Yash Technologies
Hello yash Technology