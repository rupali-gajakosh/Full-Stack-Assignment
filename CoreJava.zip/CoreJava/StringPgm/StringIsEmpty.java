class StringIsEmpty

{

 public static void main(String args[])

 {

 String s = "Hello Rupali";

 String s1 = "";

 System.out.println(s.isEmpty());

 System.out.println(s1.isEmpty());

 }

}

------output---------


D:\javapgm\StringPgm>javac StringIsEmpty.java

D:\javapgm\StringPgm>java StringIsEmpty
false
true
