class StringEualIgnoreCase

{

 public static void main(String args[])

 {

 String s = "Rupali";

  String s1 = "Rupali";



 System.out.println(s.equalsIgnoreCase(s1));

 

  String s2 = "Rupali";

  String s3 = "roopali";

  System.out.println(s2.equalsIgnoreCase(s3));
 }
 

 }
 
 -----------output---------
 
 
D:\javapgm\StringPgm>javac StringEualIgnoreCase.java

D:\javapgm\StringPgm>java StringEualIgnoreCase
true
false