class StringCompareTo

{

 public static void main(String args[])

 {

  String s = "Rupali";

  String s1 = "Rupali";

  String s2 = "Roops";

  String s3 = "Roopali";

  String s4 = "Rashmi";

 



 System.out.println(s.compareTo(s1));

 System.out.println(s.compareTo(s2));

 System.out.println(s.compareTo(s3));

 System.out.println(s.compareTo(s4));

 

 }

}