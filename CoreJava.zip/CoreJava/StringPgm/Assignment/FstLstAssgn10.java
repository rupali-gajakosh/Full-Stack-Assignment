class FstLstAssgn10
{
	public static String removeFirstandLast(String str)
	{
		str=str.substring(1,str.length()-1);
		return str;
		
	}
	public static void main(String[] args)
	{
		String str="Welcome";
		System.out.println(removeFirstandLast(str));
	}
}


------output----

C:\Users\rupali.gajakosh\Desktop>javac FstLstAssgn10.java

C:\Users\rupali.gajakosh\Desktop>java FstLstAssgn10
elcom
