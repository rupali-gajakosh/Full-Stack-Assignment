import java.util.Scanner;
class FstHalfStrAssg
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		String str=sc.nextLine();
		String s=null;
		
		int length=str.length();
		int n=length/2;
		if(length%2==0)
		{
			s=" ";
			for(int i=0;i<n;i++)
			{
				s=s+str.charAt(i);
			}
			System.out.println(s);
		}
		else
			System.out.println(s);
		sc.close();
		
	}
}

----------output----------


C:\Users\rupali.gajakosh\Desktop>javac FstHalfStrAssg.java

C:\Users\rupali.gajakosh\Desktop>java FstHalfStrAssg
jaynam
 jay

C:\Users\rupali.gajakosh\Desktop>javac FstHalfStrAssg.java

C:\Users\rupali.gajakosh\Desktop>java FstHalfStrAssg
Amit
 Am

C:\Users\rupali.gajakosh\Desktop>javac FstHalfStrAssg.java

C:\Users\rupali.gajakosh\Desktop>java FstHalfStrAssg
Jay
null