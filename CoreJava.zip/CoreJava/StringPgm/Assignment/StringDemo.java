class StringDemo
{
}