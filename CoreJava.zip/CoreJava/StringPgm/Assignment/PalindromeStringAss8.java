
public class PalindromeStringAss8
 {
 
    public static void main(String[] args)
	{
         
        String str = "Nitin";
         
        
        String rev = (new StringBuilder(str)).reverse().toString();
         
       
        if(str.equals(rev))
			{
            System.out.println(str+" is Palindrome.");
        }
		else
			{
            System.out.println(str+" is not Palindrome.");
			}
    }
}

------output----------

C:\Users\rupali.gajakosh\Desktop>javac PalindromeStringAss8.java

C:\Users\rupali.gajakosh\Desktop>java PalindromeStringAss8
Nitin is not Palindrome.