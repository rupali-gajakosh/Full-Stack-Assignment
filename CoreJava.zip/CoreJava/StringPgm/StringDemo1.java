class StringDemo1

{

 public static void main(String args[])

 {

 String s = "Welcome To Yash";

  String s1 = "Technologies";

 String s2 = new String("I am busy");

 




  System.out.println(s.equals(s1));

   System.out.println(s.equals(s2));

 }

}
-----output-------------

D:\javapgm\StringPgm>javac StringDemo1.java

D:\javapgm\StringPgm>java StringDemo1
false
false
