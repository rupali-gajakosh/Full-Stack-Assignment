public class RegexPgm1
{
	public static void main(String[] args)
	{
		String str="Rupali@1234";
		String digits=str.replaceAll("^0-9"," ");
		System.out.println(digits);
	}
}

---ouput--


C:\Users\rupali.gajakosh\Desktop>javac RegexPgm1.java

C:\Users\rupali.gajakosh\Desktop>java RegexPgm1
Rupali@1234