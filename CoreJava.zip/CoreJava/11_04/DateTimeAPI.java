import java.time.format.DateTimeFormatter;
import java.time.*;
public class DateTimeAPI
{
	public static void LocalDateTimeApi()
	{
		LocalDate date=LocalDate.now();
		System.out.println("The Current Date Is: " +date);
		
		LocalTime time=LocalTime.now();
		System.out.println("The Current Time Is: " +time);
		
		LocalDateTime current=LocalDateTime.now();
		System.out.println("The Current Date and Time Is: " +current);
		
		DateTimeFormatter format=DateTimeFormatter.ofPattern("dd-MM-yyyy  HH:mm:ss");
		
		String formatedDateTime=current.format(format);
		
		System.out.println("In Formatted Manner: "+ formatedDateTime);
		
		Month month=current.getMonth();
		int day=current.getDayOfMonth();
		int seconds =current.getSecond();
		System.out.println("Month :" + month + "Day :"+ day + "Seconds :"+seconds);
		
		LocalDateTime specificDate=current.withDayOfMonth(24).withYear(2022);
		System.out.println("specific date with :"+ "current time :"+specificDate);
	}
		public static void main(String[] args)
		{
			LocalDateTimeApi();
		}
		
		
}


-----------output-------


C:\Users\rupali.gajakosh\Desktop>javac DateTimeAPI.java

C:\Users\rupali.gajakosh\Desktop>java DateTimeAPI
The Current Date Is: 2022-04-11
The Current Time Is: 16:01:42.182
The Current Date and Time Is: 2022-04-11T16:01:42.182
In Formatted Manner: 11-04-2022  16:01:42
Month :APRILDay :11Seconds :42
specific date with :current time :2022-04-24T16:01:42.182