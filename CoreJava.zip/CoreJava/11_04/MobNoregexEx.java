
public class MobNoregexEx
{
	public static void main(String[] args)
	{
		System.out.println("721890144".matches("[1-9]\\d[2]-?\\d[3]-?\\d[4]"));
		System.out.println("s1".matches("^[a-zA-z_$][a-zA_$0-9]*"));
		System.out.println("ABC".matches("[a-zA-Z][3]"));
	}
}
----output---


C:\Users\rupali.gajakosh\Desktop>javac MobNoregexEx.java

C:\Users\rupali.gajakosh\Desktop>java MobNoregexEx
false
true
false