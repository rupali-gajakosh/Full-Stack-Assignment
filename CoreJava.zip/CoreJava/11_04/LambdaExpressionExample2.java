interface WithLambda
{  
    public void draw();  
}  
  
public class LambdaExpressionExample2 
{  
    public static void main(String[] args)
	{  
        int width=12;  
          
     
      WithLambda w2=()->{  
            System.out.println("WithLambda"+width);  
        };  
        w2.draw();  
    }  
}  

---output----

C:\Users\rupali.gajakosh\Desktop>javac LambdaExpressionExample2.java

C:\Users\rupali.gajakosh\Desktop>java LambdaExpressionExample2
WithLambda12