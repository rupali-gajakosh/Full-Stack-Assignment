class SingleToMulti extends Thread
{  
 public void run()
 {  
   System.out.println("Welcome To Yash Team");  
 }  
 public static void main(String args[])
 {  
	SingleToMulti  t1=new SingleToMulti();  
	SingleToMulti t2=new SingleToMulti();  
	SingleToMulti t3=new SingleToMulti();  
  
  t1.start();  
  t2.start();  
  t3.start();  
 }  
}

------output------


C:\Users\rupali.gajakosh\Desktop>javac SingleToMulti.java

C:\Users\rupali.gajakosh\Desktop>java SingleToMulti
Welcome To Yash Team
Welcome To Yash Team
Welcome To Yash Team
