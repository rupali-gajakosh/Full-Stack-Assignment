
public class SingleThreadDemo extends Thread
{
	public void run()
	{
		System.out.println("welcome Yash Technologies");
	}
	public static void main(String[] args)
	{
			SingleThreadDemo  td=new SingleThreadDemo();
			td.start();
	}
}

----------ouput-----


C:\Users\rupali.gajakosh\Desktop>javac SingleThreadDemo.java

C:\Users\rupali.gajakosh\Desktop>java SingleThreadDemo
welcome Yash Technologies