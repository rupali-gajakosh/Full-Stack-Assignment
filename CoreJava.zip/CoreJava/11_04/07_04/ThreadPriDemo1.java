public class ThreadPriDemo1 extends Thread
{
	public void run()
	{
		System.out.println("I run Method");
		System.out.println(Thread.currentThread().getPriority());
	}
	public static void main(String[] args)
	{
		System.out.println(Thread.currentThread().getPriority());
	Thread.currentThread().setPriority(MIN_PRIORITY);
	ThreadPriDemo1 tp=new ThreadPriDemo1();
	tp.setPriority(7);
	tp.start();
	}
}

-----output----------


C:\Users\rupali.gajakosh\Desktop>javac ThreadPriDemo1.java

C:\Users\rupali.gajakosh\Desktop>java ThreadPriDemo1
5
I run Method
7