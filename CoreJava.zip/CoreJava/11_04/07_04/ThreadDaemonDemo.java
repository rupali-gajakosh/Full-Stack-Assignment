public class ThreadDaemonDemo extends Thread
{
	public void run()
	{
		if(Thread.currentThread().isDaemon())
		{
			System.out.println("I am in Daemon thread");
		}
		else
		{
			System.out.println("I am not Daemon thread");
		}
	}
	public static void main(String[] args)
	{
		System.out.println("Main Thread");
		ThreadDaemonDemo td=new ThreadDaemonDemo();
		td.setDaemon(true);
		td.start();
	}
}

----------output----------


C:\Users\rupali.gajakosh\Desktop>javac ThreadDaemonDemo.java

C:\Users\rupali.gajakosh\Desktop>java ThreadDaemonDemo
Main Thread
I am in Daemon thread