public class ThreadDemo2 implements Runnable
{
	public void run()
	{
		System.out.println("Thread started");
	}
	public static void main(String args[])
	{
	Thread t=new Thread(new ThreadDemo2());
	t.start();
	}
}
------output---

C:\Users\rupali.gajakosh\Desktop>javac ThreadDemo2.java

C:\Users\rupali.gajakosh\Desktop>java ThreadDemo2
Thread started
