public class ThreadDemo extends Thread
{
	public void run()
	{
		System.out.println("Thread Started");
	}
	public static void main(String[] args)
	{
		ThreadDemo td=new ThreadDemo();
		td.start();
	}
}



----output----


C:\Users\rupali.gajakosh\Desktop>javac ThreadDemo.java

C:\Users\rupali.gajakosh\Desktop>java ThreadDemo
Thread Started
