public class ThreadNameDemo2 extends Thread
{
	public void run()
	
	{ 
		Thread.currentThread().setName("Run");
		System.out.println("Run:"+Thread.currentThread().getName());
	}
	public static void main(String[] args)
	{
		System.out.println(Thread.currentThread().getName());
		ThreadNameDemo2 t1=new ThreadNameDemo2();
		System.out.println(t1.isAlive());
		t1.setName("T1 Thread");
		t1.start();
		System.out.println(t1.isAlive());
		System.out.println(Thread.currentThread().isAlive());
		
		ThreadNameDemo2 t2=new ThreadNameDemo2();
		t2.setName("T2 Thread");
		t2.start();
		
		
	}
}

-----output----------


C:\Users\rupali.gajakosh\Desktop>javac ThreadNameDemo2.java

C:\Users\rupali.gajakosh\Desktop>java ThreadNameDemo2
main
false
true
true
Run:Run
Run:Run

