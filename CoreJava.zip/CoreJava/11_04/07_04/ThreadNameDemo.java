public class ThreadNameDemo
{
	public static void main(String[] args)
	{
		System.out.println(Thread.currentThread().getName());
		Thread.currentThread().setName("yash");
		System.out.println(Thread.currentThread().getName());
	}
}

----output----


C:\Users\rupali.gajakosh\Desktop>javac ThreadNameDemo.java

C:\Users\rupali.gajakosh\Desktop>java ThreadNameDemo
main
yash
