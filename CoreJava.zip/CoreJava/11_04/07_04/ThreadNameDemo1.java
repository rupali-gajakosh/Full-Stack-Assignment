public class ThreadNameDemo1 extends Thread
{
	public void run()
	
	{
		System.out.println("Run:"+Thread.currentThread().getName());
	}
	public static void main(String[] args)
	{
		System.out.println(Thread.currentThread().getName());
		ThreadNameDemo1 t1=new ThreadNameDemo1();
		t1.setName("T1 Thread");
		t1.start();
		
		ThreadNameDemo1 t2=new ThreadNameDemo1();
		t2.setName("T2 Thread");
		t2.start();
		
		
	}
}



----------output----

C:\Users\rupali.gajakosh\Desktop>javac ThreadNameDemo1.java

C:\Users\rupali.gajakosh\Desktop>java ThreadNameDemo1
main
Run:T1 Thread
Run:T2 Thread
