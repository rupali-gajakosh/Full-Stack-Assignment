public class ThreadDemo3 implements Runnable
{
	public void run()
	{
		System.out.println("Thread started");
	}
	public static void main(String args[])
	{
	ThreadDemo3 t=new ThreadDemo3();
	Thread t1=new Thread(t);
	//t.start();
	t1.start();
	
	}
}
-------output----


C:\Users\rupali.gajakosh\Desktop>javac ThreadDemo3.java

C:\Users\rupali.gajakosh\Desktop>java ThreadDemo3
Thread started
