class MultiTask1 extends Thread 
{
  public void run() 
  {
    System.out.println("India");
  }
}
class MultiTask2 extends Thread 
{
  public void run() 
  {
    System.out.println("Maharashtra");
  }
}
class MultiTask3 extends Thread 
{
  public void run() 
  {
    System.out.println("Mumbai");
  }
}
public class MultiToMultiDemo
{
  
  public static void main(String[] args) 
  {
 MultiTask1 t1 = new MultiTask1();
 MultiTask2  t2 = new MultiTask2();
 MultiTask3  t3=new MultiTask3();
    t1.start();
    t2.start();
	t3.start();
  }
}



-----output--------


C:\Users\rupali.gajakosh\Desktop>javac MultiToMultiDemo.java

C:\Users\rupali.gajakosh\Desktop>java MultiToMultiDemo
India
Mumbai
Maharashtra