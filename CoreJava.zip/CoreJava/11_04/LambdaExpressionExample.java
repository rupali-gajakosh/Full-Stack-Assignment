interface WithoutLambdaEx
{  
    public void draw();  
}  
public class LambdaExpressionExample 
{  
    public static void main(String[] args) 
	{  
        int width=12;  
  
        
         WithoutLambdaEx w1=new  WithoutLambdaEx()
		 {  
            public void draw(){System.out.println(" WithoutLambdaEx"+width);}  
        };  
        w1.draw();  
    }  
}  

--------output-----

C:\Users\rupali.gajakosh\Desktop>javac LambdaExpressionExample.java

C:\Users\rupali.gajakosh\Desktop>java LambdaExpressionExample
 WithoutLambdaEx12
