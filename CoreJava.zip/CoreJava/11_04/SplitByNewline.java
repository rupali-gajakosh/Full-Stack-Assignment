import java.util.Arrays;
public class SplitByNewline
{
	public static void main(String[] args)
	{
		String input="Rupali\r\nGajakosh";
		String[] lineArr=input.split(System.getProperty("line.separator"));
		System.out.println(Arrays.toString(lineArr));
	}
}

----output-------


C:\Users\rupali.gajakosh\Desktop>javac SplitByNewline.java

C:\Users\rupali.gajakosh\Desktop>java SplitByNewline
[Rupali, Gajakosh]