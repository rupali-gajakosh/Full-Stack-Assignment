import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class SubStringRegexPgm
{
	public static void main(String[] args)
	{
		Pattern p=Pattern.compile("\\b\\Rupali Gajakosh\\b");
		Matcher m=p.matcher("Rekha Gajakosh\n" + "Rashmi Gajakosh\n");
		while(m.find())
		
			System.out.println("Match:"+m.group());
		
	}
}