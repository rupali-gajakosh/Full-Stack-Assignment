import java.util.regex.*;
public class PrimeWithregex
{
	public static void main(String[] args)
	
public static boolean isPrime(int n) 
{
    String lengthN = new String(new char[n]);
    boolean isNotPrimeN = lengthN.matches(".?|(..+?)\\1+");
    return !isNotPrimeN;

}
}