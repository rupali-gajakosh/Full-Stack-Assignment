//import java.util.List;

public class EmailRegexPgm

{
List emails = new ArrayList();
emails.add("roopali@gmail.com");
emails.add("roopali@gmail.co.in");
emails.add("roopali19@gmail.com");
emails.add("rooplai.gajakosh@gmailin.com");
emails.add("roopali#@gmail.co.in");
emails.add("rooali@gmailcom");
 
//Invalid emails
emails.add("roopali#gmail.com");
emails.add("@yahoo.com");
 
String regex = "^(.+)@(.+)$";
 
Pattern pattern = Pattern.compile(regex);
 
for(String email : emails)
{
  Matcher matcher = pattern.matcher(email);
  System.out.println(email +" : "+ matcher.matches());
}
}