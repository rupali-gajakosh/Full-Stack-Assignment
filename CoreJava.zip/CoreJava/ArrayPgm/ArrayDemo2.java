class ArrayDemo2
{
	public static int search(int a[],int x)
	{
		int n=a.length;
		for(int i=0;i<n;i++)
		{
			if(a[i]==x)
				return i;
		}
		return -1;
	}
	public static void main(String args[])
	{
		int a[]={1,5,10,21,77};
		int x=50;
		int r=search(a,x);
		if(r==-1)
			System.out.println("Element is not present in array Index");
		else
			System.out.println("Element is present in array Index-"+r);
	}
}


---------------------output-----------------------------


C:\Users\rupali.gajakosh\Desktop>javac ArrayDemo2.java

C:\Users\rupali.gajakosh\Desktop>java ArrayDemo2
Element is not present in array
