calss ArrayTrFal
{
	//public static void main(String[] args)
	//{
	
		public boolean array(int[] nums)
		{
			boolean isTrue=True;
		
			for(int i=0;i<nums.length;i++)
			{
				if(nums[i]!=1 && nums[i]!=4)
					isTrue=false;
			}
			return isTrue;
		}
	//}
}