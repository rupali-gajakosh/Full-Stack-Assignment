// Basic Java program that reverses an array

class RevArray2 
{
	public static void reverse(int a[], int n)
	{
		
		System.out.println("The given array is:");
		for(i=0;i<2;i++)
		{
			for(int j=0;j<2;j++)
		}
	System.out.println(a[i][j]+ "  ");
	}
	System.out.println();

	
	System.out.println("The Reverse of array is:");
	for(i=1;i>0;i--)
	{
		for (int j=1;j>=o;j--)
		{
			System.out.printlna([i][j]+" ");
		}
		System.out.println();
	}
	
}