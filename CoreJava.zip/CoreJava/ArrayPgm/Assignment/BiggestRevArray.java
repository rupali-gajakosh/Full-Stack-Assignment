class BiggestRevArray
{
	public static void main(String[] args)
	{
		int[] a=new int[]{1,23,24,77,67,90,110,222,121};
		int bigno=a[0];
		for(int i=1;i<a.length;i++)
		{
			if(a[i]>bigno)
			{
				bigno=a[i];
			}
		}
		System.out.println("The given array is:");
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
		System.out.println("The Biggest No is:  " +  bigno);
	}
}

----output-------


C:\Users\rupali.gajakosh\Desktop>javac BiggestRevArray.java

C:\Users\rupali.gajakosh\Desktop>java BiggestRevArray
The given array is:
1
23
24
77
67
90
110
222
121
The Biggest No is:222