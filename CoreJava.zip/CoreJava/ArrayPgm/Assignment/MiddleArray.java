
import java.util.*;
class MiddleArray
{
	public static void main(String[] args)
	{
		int[] A1={1,2,3};
		int[] B1={4,5,6};
		System.out.println("A1:"+Arrays.toString(A1));
		System.out.println("B1:"+Arrays.toString(B1));
		int[] a_new={A1[1],B1[1]};
		System.out.println("New Arrays:"+Arrays.toString(a_new));
		
	}
}


-----------output---------

D:\javapgm\16-03-22>javac MiddleArray.java

D:\javapgm\16-03-22>java MiddleArray
A1:[1, 2, 3]
B1:[4, 5, 6]
New Arrays:[2, 5]