class MinMax
{
	public int max(int [] array)
	{
		int max=0;
		for(int i=0;i<array.length;i++)
		{
			if(array[i]>max)
			{
				max=array[i];
			}
		}
		return max;
	}	
	public int min(int [] array)
	{
		int min=array[0];
		for(int i=0;i<array.length;i++)
		{
			if(array[i]<min)
			{
				min=array[i];
			}
		}
		return min;
	}
	public static void main(String args[])
	{
	int[] noArray={10,20,30,40,50,7,60,};
	MinMax m=new MinMax();
	System.out.println("Maximum Value::"+m.max(noArray));
	System.out.println("Minimum Value::"+m.min(noArray));
	}
}




----------------------output---------------------------------------


C:\Users\rupali.gajakosh>cd Desktop

C:\Users\rupali.gajakosh\Desktop>Javac MinMax.java

C:\Users\rupali.gajakosh\Desktop>Java MinMax
Maximum Value::60
Minimum Value::7