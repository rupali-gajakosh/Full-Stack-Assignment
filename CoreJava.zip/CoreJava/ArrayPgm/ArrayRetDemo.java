class ArrayRetDemo
{
	public static void main(String[] args)
	{
	int[] a={10,20,30};
	for(int i=0;i<a.length;i++)
	{
	System.out.println(a[i]+" ");
	}
	}
}


------output--------


D:\javapgm\16-03-22>javac ArrayRetDemo.java

D:\javapgm\16-03-22>java ArrayRetDemo
10
20
30