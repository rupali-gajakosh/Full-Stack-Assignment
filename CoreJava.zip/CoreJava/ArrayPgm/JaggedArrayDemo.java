class JaggedArrayDemo
{
	public static void main(String[] args)
	{
	int[][] a={{10,20,30},{40,50},{60,70,80}};
	System.out.println(a[1].length); 
	//System.out.println(a);------------------o/p=Hashvalue
	
	}
	{
	System.out.println();
	
	}
}

------output------

D:\javapgm\16-03-22>javac JaggedArrayDemo.java

D:\javapgm\16-03-22>java JaggedArrayDemo
2
