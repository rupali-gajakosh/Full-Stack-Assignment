import java.util.*;
class OneDArray
{
	public static void main(String[] args)
	{
		int n,sum=0;
		float avg;
		Scanner s=new Scanner(System.in);
		System.out.println("Enter OneD Array Number:");
		n=s.nextInt();
		int a[]=new int[n];
		System.out.println("Enter all the element:");
		for(int i=0;i<n;i++)
		{
			a[i]=s.nextInt();
			sum=sum+a[i];
			
		}
		System.out.println("Sum:"+sum);
		avg=(float)sum/n;
		System.out.println("Average:"+avg);
	}
}


----------------output----------


D:\javapgm\16-03-22>javac OneDArray.java

D:\javapgm\16-03-22>java OneDArray
Enter OneD Array Number:
7
Enter all the element:
12
2
3
4
5
6
7
Sum:39
Average:5.571429
