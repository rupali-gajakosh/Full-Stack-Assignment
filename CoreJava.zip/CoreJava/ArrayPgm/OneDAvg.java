class OneDAvg
{
	public static void main(String[] args)
	{
		int no[]={2,4,6,3,8,9,5};
		double result=0;
		int i;
		for(i=0;i<7;i++)
		{
			result=result+no[i];
		}
		System.out.println("Average is:"+result/7);
	}
}
----output-----


D:\javapgm\16-03-22>javac OneDAvg.java

D:\javapgm\16-03-22>java OneDAvg
Average is:5.285714285714286
