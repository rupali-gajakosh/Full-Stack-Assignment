class LeapYear
{
	public static void main(String[] args)
	{
		int year=2022;
		if(year%400==0 || (year%4==0 && year %100!=0))
		
			
				{
					System.out.println("Leap year");
				}
				else
				{
					System.out.println("Not a Leap year");
				}
	}			
}

------------output---------------


D:\javapgm\Day__1\Assignment>javac LeapYear.java

D:\javapgm\Day__1\Assignment>java LeapYear
Not a Leap year
