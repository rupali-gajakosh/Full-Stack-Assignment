class LargestThreeNo
{
	public static void main(String[] args)
	{
		int a=10,b=20,c=30;
		if(a>b && a>c)
		{
			System.out.println("a is Largest");
		}
		else if(b>a && b>c)
		{
			System.out.println("b is Largest");
		}
		else
		{
			System.out.println("c is Largest");
		}
	}
}

------output--------------


D:\javapgm\Day__1\Assignment>javac LargestThreeNo.java

D:\javapgm\Day__1\Assignment>java LargestThreeNo
c is Largest