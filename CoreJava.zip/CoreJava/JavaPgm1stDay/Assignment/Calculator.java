class Calculator
{
	public static void main(String[] args)
	{
		int no1=10,no2=20,result;
		String syb="+";
		switch(syb)
		{
			case "+" : result=no1+no2;
					System.out.println(result);
					break;
			case "-" : result=no1+no2;
			
					System.out.println(result);
					break;
			case "*" : result=no1+no2;
					System.out.println(result);
					break;
			case "/" : result=no1+no2;
					System.out.println(result);
					break;
					
			default : System.out.println("invalid symbole");
					break;
					
		}
	}
}

-----output---------


D:\javapgm\Day__1\Assignment>javac Calculator.java

D:\javapgm\Day__1\Assignment>java Calculator
30