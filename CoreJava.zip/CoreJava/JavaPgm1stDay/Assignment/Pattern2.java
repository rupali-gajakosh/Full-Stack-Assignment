class Pattern2
{
	public static void main(String args[])
	{
	int i,j,n=6;
	{
	for(i=n-1;i>0;i--)
	{
	for(j=1;j<=i;j++)
	{
	System.out.print("*"+"" );
	}
	System.out.println();
	}
	}
	}
}


--------output---------------------------


D:\javapgm\Day__1\Assignment>javac Pattern2.java

D:\javapgm\Day__1\Assignment>java Pattern2
*****
****
***
**
*