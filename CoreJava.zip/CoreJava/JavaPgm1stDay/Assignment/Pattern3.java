class Pattern3
{
	public static void main(String args[])
	{
		int i,j,n=5;
		for(i=1;i<=5;i++)
		{
			for(j=1;j<=i;j++)
			{
				System.out.print("*");
			}
			System.out.println();
		}
		for(i=1;i<=5;i++)
		{
			for(j=5;j>=i;j--)
			{
				System.out.print("*");
				
			}
			System.out.println();
		}
	}
}


-------output---------

D:\javapgm\Day__1\Assignment>javac Pattern3.java

D:\javapgm\Day__1\Assignment>java Pattern3
*
**
***
****
*****
*****
****
***
**
*
