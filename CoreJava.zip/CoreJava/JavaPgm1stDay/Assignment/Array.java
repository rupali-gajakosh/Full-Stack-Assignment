
class Array
{
	public static void main(String[] args)
	{ 
		public boolean Array(int[] nums)
		{ int count=0;
			for(int element: nums)
			{
				if(element !=4 && element !=1)
				{
					count++;
				}					
			}
			if(count >0)
			{
				return false;
			}
			else
			{
				return true;
				
			}
		}
	} 
}