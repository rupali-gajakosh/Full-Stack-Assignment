 class LargestTwoNo
{
   public static void main(String[] args)
   {
	int a=10,b=20;
	if(a>b)
	{
		System.out.println(a);
		
	}
	else
	{
		System.out.println(b);
	}
	
   }
}

-------output------


D:\javapgm\Day__1\Assignment>javac LargestTwoNo.java

D:\javapgm\Day__1\Assignment>java LargestTwoNo
20