class SwapTwoNo1
{
 public static void main(String[] args)
 {
	 int a=10,b=20;
	 int t;
	 t=a;
	 a=b;
	 b=t;
	 System.out.println("a" +a);
	 System.out.println("b" +b);
 }
}


-------output----------



D:\javapgm\Day__1\Assignment>javac SwapTwoNo1.java

D:\javapgm\Day__1\Assignment>java SwapTwoNo1
a20
b10