class SwapTwoNo
{
 public static void main(String[] args)
 {
	 int a=10,b=20;
	 a=a+b;
	 b=a-b;
	 a=a-b;
	 
	 System.out.println("a"+a);
	 System.out.println("b"+b);
	 
	
	 
 }
}


----output------------


D:\javapgm\Day__1\Assignment>javac SwapTwoNo.java

D:\javapgm\Day__1\Assignment>java SwapTwoNo
a20
b10