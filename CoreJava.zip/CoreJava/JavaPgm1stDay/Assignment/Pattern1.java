class Pattern1
{
	public static void main(String args[])
	{
		int i,j,n=5;
	
	for(i=0;i<n;i++)
	{
	for(j=0;j<=i;j++)
	
	{
		System.out.print("*");
	}
		System.out.println();
	
	}
	}
}

----------output--------------


D:\javapgm\Day__1\Assignment>javac Pattern1.java

D:\javapgm\Day__1\Assignment>java Pattern1
*
**
***
****
*****