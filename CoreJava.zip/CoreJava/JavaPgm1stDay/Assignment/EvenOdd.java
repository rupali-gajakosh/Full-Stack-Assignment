class EvenOdd
{
	public static void main(String args[])
	{
		int no=75;
		if(no%2==0)
		{
			System.out.println("Number is even");
		}
		else
		{
			System.out.println("Number is odd");
			
		}
	}
}


----------output----------


D:\javapgm\Day__1\Assignment>javac EvenOdd.java

D:\javapgm\Day__1\Assignment>java EvenOdd
Number is odd