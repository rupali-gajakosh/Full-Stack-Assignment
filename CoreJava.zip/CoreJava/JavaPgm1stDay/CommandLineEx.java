class CommandLineEx
	{
		public static void main(String[] args)
			{
				System.out.print("Your First Argument:"+args[0]);
				System.out.print("Your Second Argument:"+args[1]);
			
			}
	}
