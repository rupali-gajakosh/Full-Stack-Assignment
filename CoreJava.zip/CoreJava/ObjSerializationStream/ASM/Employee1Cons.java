//using constructor
import java.io.*;
import java.util.Scanner;

	class Employee implements Serializable
	{
	private String name;
	private String department;
	private String designation;
	private double salary;
	public Employee()
	{
	System.out.println("In no-arg constructor of employee class");
	}
	public Employee(String name,String department,String designation,double salary)
	{
	this.name=name;
	this.department=department;
	this.designation=designation;
	this.salary=salary;
	}
	public String toString()
	{
	return name + " "+ department + " " + designation + " " + salary;
	}
	}
	class Employee1Cons
	{
	public static void main(String[] args) throws Exception
	{
	Employee e = new Employee("Rupali","IT","Trainee Associate",10000);
	File f = new File("d:/yash/Emp.txt");
	ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(f));
	oos.writeObject(e);
	ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f));
	e = (Employee)ois.readObject();
	System.out.println(e);
	ois.close();
	oos.close();
	}
}

-----output---


D:\Day11\ASM>javac Employee1Cons.java

D:\Day11\ASM>java Employee1Cons
Rupali IT Trainee Associate 10000.0