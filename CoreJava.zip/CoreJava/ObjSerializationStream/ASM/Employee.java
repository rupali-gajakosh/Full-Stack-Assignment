
import java.io.*;
class Employee implements Serializable
	{
	private String name;
	private String department;
	private String designation;
	private double salary;
	public void setName(String name)
	{
	this.name=name;
	}
	
	public void setDepartment(String department)
	{
	this.department=department;
	}
	
	public void setDesignation(String designation)
	{
	this.designation=designation;
	}
	
	public void setSalary(double salary)
	{
	this.salary=salary;
	}
	
	public String getName()
	{
	return name;
	}
	
	public String getDepartment()
	{
	return department;
	}
	
	public String getDesignation()
	{
	return designation;
	}
	
	public double getSalary()
	{
	return salary;
	}
	
	public static void main(String args[]) throws Exception
	{
	Employee emp = new Employee();
	emp.setName("Rupali");
	emp.setDepartment("IT");
	emp.setDesignation("Java full Stack trainee");
	emp.setSalary(10000.00);
	File f = new File("D:/Day11/ASM/emp.txt");
	f.createNewFile();
	ObjectOutputStream oos= new ObjectOutputStream(new FileOutputStream(f));
	oos.writeObject(e);
	ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f));
	Employee emp1=(Employee) ois.readObject();
	System.out.println("Empoyee Name:"+emp1.getName());
	System.out.println("Empoyee Department:"+emp1.getDepartment());
	System.out.println("Empoyee Designation:"+emp1.getDesignation());
	System.out.println("Empoyee Salary:"+emp1.getSalary());
	oos.close();
	ois.close();
	}
}

-------output-------


D:\Day11\ASM>javac Employee.java

D:\Day11\ASM>java Employee
Empoyee Name:Rupali
Empoyee Department:IT
Empoyee Designation:Java full Stack trainee
Empoyee Salary:10000.0

