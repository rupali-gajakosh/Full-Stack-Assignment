class EnumSeason
{
public enum Season{WINTER,SPRING,SUMMER,FALL}

public static void main(String[] args)
{
	for(Season s:Season.values())
	{
		System.out.println(s);
	}
	System.out.println("Value of SUMMER is"+Season.valueOf("SUMMER"));
	System.out.println("INDEX of SUMMER is"+Season.valueOf("SUMMER").ordinal());
	
	System.out.println("INDEX of WINTER is"+Season.valueOf("WINTER").ordinal());
	
	
}
}

-----output----


C:\Users\rupali.gajakosh\Desktop>javac EnumSeason.java

C:\Users\rupali.gajakosh\Desktop>java EnumSeason
WINTER
SPRING
SUMMER
FALL
Value of SUMMER isSUMMER
INDEX of SUMMER is2
INDEX of WINTER is0