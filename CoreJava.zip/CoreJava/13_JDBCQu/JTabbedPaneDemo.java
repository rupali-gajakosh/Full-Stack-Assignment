import javax.swing.*;
public class JTabbedPaneDemo extends JApplet
{
	public void init()
	{
		JTabbedPane jtp=new JTabbedPane();
		jtp.addTab("Cities",new CitiesPanel());
		jtp.addTab("Colors",new ColorsPanel());
		jtp.addTab("Flavors",new FlavorsPanel());
		getContentPane().add(jtp);
	}
}
class CitiesPanel extends Jpanel
{
	public CitiesPanel()
	{
		JButton b1=new JButton("Mumbai");
		add(b1);
		
		JButton b2=new JButton("pune");
		add(b2);
		
		JButton b3=new JButton("Solapur");
		add(b3);
		
		JButton b4=new JButton("Kolhapur");
		add(b4);
		
	}
}
class ColorsPanel extends JPanel
{
	public ColorsPanel()
	{
		JCheckBox cb1=new JCheckBox("Red");
		add(cb1);
		
		JCheckBox cb2=new JCheckBox("Yellow");
		add(cb2);
		
		JCheckBox cb3=new JCheckBox("Green");
		add(cb3);
		
	}
}

class FlavorsPanel extends JPanel
{
	public FlavorsPanel()
	{
		JComboBox jcb=new JCheckBox();
		jcb.addItem("Vanilla");
		jcb.addItem("Chocolate");
		jcb.addItem("Strawberry");
		add(jcb);
	}
}