 import java.sql.*;  
 import java.io.*;
 
class PreparedBufferedStmnt
{  
public static void main(String args[])
{  
try
{  
	Class.forName("com.mysql.jdbc.Driver");
	//create connection
	String url="jdbc:mysql://localhost:3306/rupali";
	String user="root";
	String pass="root";
	Connection con=DriverManager.getConnection(url,user,pass);
	String q="insert into employee(empID,empName) values(?,?)";
	PreparedStatement stmt=con.prepareStatement(q);  
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	System.out.println("Enter EmpID: ");
	int id=Integer.parseInt(br.readLine());
	System.out.println("Enter EmpName: ");
	String name=br.readLine();
	
	stmt.setInt(1,id);//1 specifies the first parameter in the query  
	stmt.setString(2,name);  
  
	int i=stmt.executeUpdate();  
	System.out.println(" records inserted");  
  
	con.close();  
  
	}catch(Exception e) 
{ 	
	System.out.println(e);
	}  
  
	}  
}  


-----output----------


C:\Users\rupali.gajakosh>cd desktop

C:\Users\rupali.gajakosh\Desktop>javac PreparedBufferedStmnt.java

C:\Users\rupali.gajakosh\Desktop>java PreparedBufferedStmnt
Loading class `com.mysql.jdbc.Driver'. This is deprecated. The new driver class is `com.mysql.cj.jdbc.Driver'. The driver is automatically registered via the SPI and manual loading of the driver class is generally unnecessary.
Enter EmpID:
1007
Enter EmpName:
dishani
 records inserted
 
 
 
 mysql> select * from employee;
+-------+---------+
| empID | empName |
+-------+---------+
|  1001 | payal   |
|  1002 | nisha   |
|  1003 | shubham |
|  1004 | rupali  |
|  1005 | ritu    |
|  1006 | Shree   |
|  1007 | dishani |
+-------+---------+