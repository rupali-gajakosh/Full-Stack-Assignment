import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;



public class ImageInsert 
{
	public static void main(String[] args)
	{
		try
		{
		
	Class.forName("com.mysql.jdbc.Driver");
	//create connection
	String url="jdbc:mysql://localhost:3306/rupali";
	String user="root";
	String pass="root";
	Connection con=DriverManager.getConnection(url,user,pass);
	PreparedStatement ps=con.prepareStatement("insert into image values(?,?)");
	ps.setString(1,"Capture1");
	
	FileInputStream f=new FileInputStream("d:\\Capture1.jpg");
	ps.setBinaryStream(2,f,f.available());
	int i=ps.executeUpdate();
	System.out.println("Inserted Image..");
	con.close();
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	}
}
