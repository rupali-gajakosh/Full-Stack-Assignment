import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.Reader;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
public class ReadingDataFromBlobandClob 
{
   public static void main(String args[]) throws Exception
   {
      
      DriverManager.registerDriver(new com.mysql.jdbc.Driver());
    
      String url = "jdbc:mysql://localhost/rupali";
      Connection con = DriverManager.getConnection(url, "root", "root");
      System.out.println("Connection established......");
      
      String query = "INSERT INTO image(img,empName) VALUES (?, ?)";
      PreparedStatement pstmt = con.prepareStatement(query);
      pstmt.setString(1, "Yash Tech");
      FileReader fileReader = new FileReader("D:\\abc.txt");
      pstmt.setClob(2, fileReader);
      InputStream inputStream = new FileInputStream("D:\\Capture2.jpg");
      pstmt.setBlob(3, inputStream);
      pstmt.execute();
      System.out.println("Record inserted......");
      
      Statement stmt = con.createStatement();
      ResultSet rs = stmt.executeQuery("SELECT * from image");
      while(rs.next())
		  {
        // String name = rs.getString("image");
         Clob clob = rs.getClob("img");
         Blob blob = rs.getBlob("empName");
         System.out.println("Name: "+empName);
         System.out.println("Clob value: "+clob);
         System.out.println("Blob value: "+blob);
         System.out.println("");
         System.out.print("Clob data is stored at: ");
         //Storing clob to a file
         int i, j =0;
         Reader r = clob.getCharacterStream();
         String filePath = "D:\\"+empName+"abc.txt";
         FileWriter writer = new FileWriter(filePath);
         while ((i=r.read())!=-1) {
               writer.write(i);
         }
         writer.close();
         System.out.println(filePath);
         j++;
         System.out.print("Blob data is stored at: ");
         InputStream is = blob.getBinaryStream();
         byte byteArray[] = new byte[is.available()];
         is.read(byteArray);
         filePath = "D:\\"+empName+"Capture2.jpg";
         FileOutputStream outPutStream = new FileOutputStream(filePath);
         outPutStream.write(byteArray);
         System.out.println(filePath);
      }
   }
}