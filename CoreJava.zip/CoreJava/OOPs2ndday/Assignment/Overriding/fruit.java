import java.util.*;
class fruit
{
	protected char name,taste,size;
	Scanner s=new Scanner(System.in);
	public void eat()
	{
	 Scanner s=new Scanner(System.in);	
	  System.out.println("Enter the fruit name");
		//name =nextChar();
	  System.out.println("Enter the fruit taste");
	 // taste=nextChar();
	  
	  System.out.println("Name of fruit is"+name);
	 
	  System.out.println("taste of the fruit is"+taste);
	 
	 }
	}
	class apple extends fruit
	{
		public void eat()
		{
			System.out.println("Name of fruit is Apple");
	 
			System.out.println("taste of the fruit is sweet");
		}
	}
	class orange extends fruit
	{
		public void eat()
		{
			System.out.println("Name of fruit is orange");
	 
			System.out.println("taste of the fruit is sour");
		}
	}
	class method1
	{
		public static void main(String[] args)
		{
			apple a=new apple();
			a.eat();
			orange o= new orange();
			o.eat();
		}
	}
	
	
-------------------------------output------------------------------------
C:\Users\rupali.gajakosh>cd Desktop

C:\Users\rupali.gajakosh\Desktop>javac fruit.java

C:\Users\rupali.gajakosh\Desktop>java method1
Name of fruit is Apple
taste of the fruit is sweet
Name of fruit is orange
taste of the fruit is sour
