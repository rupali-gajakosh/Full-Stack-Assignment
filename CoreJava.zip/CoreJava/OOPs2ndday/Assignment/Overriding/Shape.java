class shape
{
	void draw()
	{
		System.out.println("Drawing shap");
	}
	void erase()
	{
		System.out.println("Erasing shap");
	}
}
class Circle extends shape
{
	void draw()
	{
		System.out.println("Drawing Circle");
	}
	void erase()
	{
		System.out.println("Erasing Circle");
	}
}
class Triangle extends shape
{
	void draw()
	{
		System.out.println("Drawing Triangle");
	}
	void erase()
	{
		System.out.println("Erasing Triangle");
	}
}
class Square extends shape
{
	void draw()
	{
		System.out.println("Drawing Square");
	}
	void erase()
	{
		System.out.println("erasing Square");
	}
}
 class method
{
	public static void main(String args[])
	{
		shape c=new Circle();
		shape t=new Triangle();
		shape s=new Square();
		c.draw();
		c.erase();
		t.draw();
		t.erase();
		s.draw();
		s.erase();
	}
}




-------------------------------------output------------------------------


C:\Users\rupali.gajakosh\Desktop>javac shape.java

C:\Users\rupali.gajakosh\Desktop>java method
Drawing Circle
Erasing Circle
Drawing Triangle
Erasing Triangle
Drawing Square
erasing Square