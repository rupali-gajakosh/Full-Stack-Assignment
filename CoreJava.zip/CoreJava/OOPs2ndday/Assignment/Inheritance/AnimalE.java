class AnimalE
{
	public void eat()
	{
		System.out.println("eat method");
	}
	public void sleep()
	{
		System.out.println("sleep method");
	}
}
class Bird extends AnimalE
{
	public void eat()
	{
		super.eat();
		System.out.println("In eat method");
	}
	public void sleep()
	{
		super.sleep();
		System.out.println("In sleep method");
	}
	public void fly()
	{
		System.out.println("In fly method");
	}
}
class Animal1
{
	public static void main(String[] args)
	{
		AnimalE a=new AnimalE();
		Bird b=new Bird();
		a.eat();
		a.sleep();
		b.eat();
		b.sleep();
		b.fly();
		
	}
}


-----------------------------output-------------------------


C:\Users\rupali.gajakosh\Desktop>javac AnimalE.java

C:\Users\rupali.gajakosh\Desktop>java Animal1
eat method
sleep method
eat method
In eat method
sleep method
In sleep method
In fly method