class Person
{
	private String name;
	private String dob;
	
	Person(String name, String dob){
		this.name = name;
		this.dob = dob;
	}
	
	Person()
	{
		this.name = null;
		this.dob = null;
	}
	
	String getName()
	{
		return this.name;
	}
	
	String getDob()
	{
		return this.dob;
	}
	
	void setName(String name)
	{
		this.name = name;
	}
	
	void setDob(String dob)
	{
		this.dob = dob;
	}
	
	public String toString()
	{
		return " Person Name: " + this.name + ", Person DOB: " + this.dob + " ";
	}
}

class Teacher extends Person
{
	private Person person;
	private int salary;
	private String subjects;
	
	Teacher()
	{
		this.person = null;
		this.salary  = 0;
		this.subjects = null;
	}
	
	Teacher(Person person, int salary, String subjects)
	{
		this.person = person;
		this.salary = salary;
		this.subjects = subjects;
	}
	
	Person getPerson()
	{
		return this.person;
	}
	
	int getSalary()
	{
		return this.salary;
	}
	
	String getSubjects()
	{
		return this.subjects;
	}
	
	void setPerson(Person person)
	{
		this.person = person;
	}
	
	void setSalary(int salary)
	{
		this.salary = salary;
	}
	
	void subjects(String subjects)
	{
		this.subjects = subjects;
	}
	
	public String toString()
	{
		return this.person.toString() + ", Salaray : " + this.salary + ", Subjects: " + this.subjects + " ";
	}
}

class CollegeStudent
{
	private Person person;
	private int studentId;
	
	CollegeStudent()
	{
		this.person =  null;
		this.studentId = 0;
	}
	
	CollegeStudent(Person person, int studentId)
	{
		this.person = person;
		this.studentId = studentId;
	}
	
	Person getPerson()
	{
		return this.person;
	}
	
	int getStudentId()
	{
		return this.studentId;
	}
	
	void setPerson(Person person)
	{
		this.person = person;
	}
	
	void setStudentId(int studentId)
	{
		this.studentId = studentId;
	}
	
	public String toString()
	{
		return this.person.toString() + ",  College Student Id: "+ this.studentId+ " ";
	}
	
	public static void main(String[] args)
	{
		// Class Person
		// Class Teacher inherits Person
		// CollegeStudent inherits Person
		
		Person p1 = new Person("Rupali", "22/09/1996");
		System.out.println(p1);
		Teacher t = new Teacher(p1, 10000, "Java");
		System.out.println(t);
		Person p2 = new Person("PQR", "19/10/1994");
		CollegeStudent s = new CollegeStudent(p2, 10);
		System.out.println(s);
		
		// Changing Student Id for Shyam
		s.setStudentId(20);
		System.out.println(s);
	}
}



-----------------------------output----------------------------------


C:\Users\rupali.gajakosh\Desktop>javac Person.java

C:\Users\rupali.gajakosh\Desktop>java  CollegeStudent
 Person Name: Rupali, Person DOB: 22/09/1996
 Person Name: Rupali, Person DOB: 22/09/1996 , Salaray : 10000, Subjects: Java
 Person Name: PQR, Person DOB: 19/10/1994 ,  College Student Id: 10
 Person Name: PQR, Person DOB: 19/10/1994 ,  College Student Id: 20
