
class Author {
   
   private String name;
   private String email;
   private char gender;   
 
   
   public Author(String name, String email, char gender) {
      this.name = name;
      this.email = email;
      this.gender = gender;
   }
 
   public String getName() {
      return name;
   }
   
   public char getGender() {
      return gender;
   }
   
   public String getEmail() {
      return email;
   }
   
   public void setEmail(String email) {
      this.email = email;
   }
 
  
   public String toString() {
      return name + " (" + gender + ") at " + email;
   }

 class TestAuthor
 {
   public static void main(String[] args) 
   {
      
      Author at = new Author("Good Gift", "abcd19@gmail.com", 'm');
      System.out.println(at);  // toString()
      

      
      at.setEmail("abcd19@gmail");
      System.out.println(at);  // toString()
      
      System.out.println("name is: " + at.getName());
     
      System.out.println("gender is: " + at.getGender());
     
      System.out.println("email is: " + at.getEmail());
      
   }
}

/*
------------------------------output--------------

C:\Users\rupali.gajakosh\Desktop>javac Author.java

C:\Users\rupali.gajakosh\Desktop>java TestAuthor
Good Gift (m) at abcd19@gmail.com
Good Gift (m) at abcd19@gmail
name is: Good Gift
gender is: m
email is: abcd19@gmail

*/