class BookTicket
{
	int totalseats=12;
	void bookSeat(int seats)
	{
		if(totalseats>=seats)
		{
			System.out.println("Booked Sucessfully:");
			totalseats=totalseats-seats;
			System.out.println("Remaining seats"+totalseats);
		}
		else
		{
			System.out.println("seats are not available"+totalseats);
		}
	}
}
public class TicketWithSyncro1 extends Thread
{ 
	static BookTicket b;
		int seats;
		public void run()
		{
			b.bookSeat(seats);
			
		}
	public static void main(String[] args)
	{
		b=new BookTicket();
		TicketWithSyncro1 p1=new TicketWithSyncro1();
		p1.seats=8;
		p1.start();
		TicketWithSyncro1 p2=new TicketWithSyncro1();
		p2.seats=10;
		p2.start();
		
	}
}

-----------output--------


C:\Users\rupali.gajakosh\Desktop>javac TicketWithSyncro1.java

C:\Users\rupali.gajakosh\Desktop>java TicketWithSyncro1
Booked Sucessfully:
Booked Sucessfully:
Remaining seats-6
Remaining seats4