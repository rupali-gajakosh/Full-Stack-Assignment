class BookTicket
{
	 int totalseats=12;
	synchronized void bookseat(int seats)
	{
		if(totalseats>=seats)
		{
			System.out.println("Booked Sucessfully");
			totalseats=totalseats-seats;
			System.out.println("Remaning seats: "+totalseats);
		}
		else
		{
			System.out.println("Seats are not available"+totalseats);
		}
	}
}
public class TicketWithSyncro extends Thread
{
	static BookTicket b;
	int seats;
	public void run()
	{
		b.bookseat(seats);
	}
	public static void main(String[] args)
	{
		b=new BookTicket();
		TicketWithSyncro p1=new TicketWithSyncro();
		p1.seats=8;
		p1.start();
		
		TicketWithSyncro p2=new TicketWithSyncro();
		p2.seats=10;
		p2.start();
		
		
	}
}

-----------output-----


C:\Users\rupali.gajakosh\Desktop>javac TicketWithSyncro.java

C:\Users\rupali.gajakosh\Desktop>java TicketWithSyncro
Booked Sucessfully
Remaning seats: 4
Seats are not available4