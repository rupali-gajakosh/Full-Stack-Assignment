import java.io.ByteArrayInputStream;
class BytearrayInputstreamDemo
{
	public static void main(String args[])
	{
		byte[] a={1,2,3,4};
		try
		{
			ByteArrayInputStream in=new ByteArrayInputStream(a);
			System.out.println("The byte array read the input:");
			for(int i=0;i<a.length;i++)
			{
				int d=in.read();
				System.out.print(d +" , ");
				
			}
			in.close();
		}
		catch(Exception e)
		{
			e.getStackTrace();
		}
	}
}

--------output----------


C:\Users\rupali.gajakosh\Desktop>javac BytearrayInputstreamDemo.java

C:\Users\rupali.gajakosh\Desktop>java BytearrayInputstreamDemo
The byte array read the input:
1 , 2 , 3 , 4 