import java.io.BufferedInputStream;
import java.io.FileInputStream;
class BufferedDemo
{
	public static void main(String[] args)
	{
		try
		{
			FileInputStream fin=new FileInputStream("d:/yash/xyz.txt");
			BufferedInputStream bin=new BufferedInputStream(fin);
			int i;
			while((i=bin.read())!=-1)
			{
				System.out.print((char)i);
			
			}
			bin.close();
			fin.close();
		}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		
	}
}

------output------


C:\Users\rupali.gajakosh\Desktop>javac BufferedDemo.java

C:\Users\rupali.gajakosh\Desktop>java BufferedDemo
hello yash team..