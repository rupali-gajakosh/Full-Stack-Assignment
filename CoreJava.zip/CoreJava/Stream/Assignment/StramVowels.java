

import java.io.FileReader;
class StramVowels
{
	public static void main(String[] args) throws Exception
	{
		
		int a = 0; //initial 0 (null to all vowels)
		int e = 0;
		int i = 0;
		int o = 0;
		int u = 0;
		
		FileReader in = new FileReader("d:/yash/abc.txt");
		int vow;
		while((vow = in.read()) != -1)
		{
			char c = (char)vow;
			if(c == 'a' || c == 'A')
			{
				a++;
			}
			if(c == 'e' || c == 'E')
			{
				e++;
			}
			if(c == 'i' || c == 'I')
			{
				i++;
			}
			if(c == 'o' || c == 'O')
			{
				o++;
			}
			if(c == 'u' || c == 'U')
			{
				u++;
			}
		}
		
		System.out.println("Number of a: " +  a);
		System.out.println("Number of e: " +  e);
		System.out.println("Number of i: " +  i);
		System.out.println("Number of o: " +  o);
		System.out.println("Number of u: " +  u);
	}
}
------output------


C:\Users\rupali.gajakosh\Desktop>javac StramVowels.java

C:\Users\rupali.gajakosh\Desktop>java StramVowels
Number of a: 0
Number of e: 4
Number of i: 0
Number of o: 2
Number of u: 0