//pgm to count no. of lines, words , characters and spaces in a text file.
import java.io.*;

public class StrmCount 
{
	public static void main(String[] args) throws IOException
	{
		File file = new File("d:/yash/abc.txt");
		FileInputStream fileInputStream = new FileInputStream(file);
		InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream);
		BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
		
		String line;
		int wordCount = 0;
		int characterCount = 0;
		int SpaceCount = 0;
		while ((line = bufferedReader.readLine()) != null)
		{
			{
				characterCount += line.length();
				String words[] = line.split("\\s+");
				wordCount += words.length;
				SpaceCount += wordCount - 1;
			}
			
		}
		System.out.println("Total word count = "+ wordCount);
	
		System.out.println("Total number of characters = "+ characterCount);
		
		System.out.println("Total number of spaces = "+ SpaceCount);
	}
}
-----output------


C:\Users\rupali.gajakosh\Desktop>javac StrmCount.java

C:\Users\rupali.gajakosh\Desktop>java StrmCount
Total word count = 3
Total number of characters = 15
Total number of spaces = 2