import java.io.*;
class SequenceInputDemo
{
	public static void main(String[] args) throws Exception
	{
		FileInputStream f1=new FileInputStream("d:/yash/abc.txt");
		FileInputStream f2=new FileInputStream("d:/yash/xyz.txt");
		SequenceInputStream st=new SequenceInputStream(f1,f2);
		int i;
		while((i=st.read())!=-1)
		{
			System.out.print((char)i);
		}
		st.close();
		f1.close();
		f2.close();
	}
}

------output------


C:\Users\rupali.gajakosh\Desktop>javac SequenceInputDemo.java

C:\Users\rupali.gajakosh\Desktop>java SequenceInputDemo
hello every onehello yash team..