
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class Assignment1 {

	public static void main(String[] args) 
	{
		Map<String, String> map = new HashMap<>();
		
		map.put("Rupali", "Yash Technologies");
		map.put("Karishma", "TCS");
		map.put("Vaibhav", "Google");
		map.put("Akshay","Mindtree");
		
	
		Set<Entry<String, String>> set = map.entrySet();
		Iterator<Entry<String, String>> it = set.iterator();
		
		while (it.hasNext()) 
		{
			Map.Entry<String, String> me = it.next();
			
			if (me.getKey().equals("Vaibhav"))
				{
				System.out.println("Key Vaibhav exists");
				break;
			}
		}
		
		
		set = map.entrySet();
		it = set.iterator();
		
		while (it.hasNext()) 
		{
			Map.Entry<String, String> me = it.next();
			
			if (me.getValue().equals("Karishma"))
				{
				System.out.println("Value Karishma exists");
				break;
			}
		}
		
		
		set = map.entrySet();
		it = set.iterator();
		
		while (it.hasNext()) 
		{
			Map.Entry<String, String> me = it.next();
			System.out.println(me);
			
		}
	}

}



------------output----------

C:\Users\rupali.gajakosh\Desktop>javac Assignment1.java

C:\Users\rupali.gajakosh\Desktop>java Assignment1
Key Vaibhav exists
Rupali=Yash Technologies
Akshay=Mindtree
Vaibhav=Google
Karishma=TCS
