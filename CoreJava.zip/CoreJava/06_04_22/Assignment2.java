import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

public class Assignment2
{

	public static void main(String[] args)
	{
		
		Properties pro = new Properties();
		
		pro.setProperty("Maharashtra", "Mumbai");
		pro.setProperty("Madhya Pradesh", "Indore");
		pro.setProperty("Karnataka", "Belgam");

		Set<Entry<Object, Object>> set = pro.entrySet();
		Iterator<Entry<Object, Object>> itr = set.iterator();
		
		while (itr.hasNext()) 
		{
			Entry<Object, Object> e = itr.next();
			System.out.println(e);
		}
	}

}


-----------output--------------


C:\Users\rupali.gajakosh\Desktop>javac Assignment2.java

C:\Users\rupali.gajakosh\Desktop>java Assignment2
Karnataka=Belgam
Maharashtra=Mumbai
Madhya Pradesh=Indore