import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

class ContactList {
	HashMap<String, Integer> contacts = new HashMap<>();
	
	public void addContact(String name, Integer number) {
		contacts.put(name, number);
	}
	
	public void removeContact(String name) {
		contacts.remove(name);
	}


	public String toString() {
		return "ContactList [contacts=" + contacts + "]";
	}
	
	public boolean doesContactNameExist(String name) {
		Set<Entry<String, Integer>> set = contacts.entrySet();
		Iterator<Entry<String, Integer>> it = set.iterator();
		
		while (it.hasNext()) {
			Map.Entry<String, Integer> me = it.next();
			
			if (me.getKey().equals(name)) {
				return true;
			}
		}
		
		return false;
	}
	
	public boolean doesContactNumberExist(Integer number) {
		Set<Entry<String, Integer>> set = contacts.entrySet();
		Iterator<Entry<String, Integer>> it = set.iterator();
		
		while (it.hasNext()) {
			Map.Entry<String, Integer> me = it.next();

			//System.out.println(me.getValue() + " == " + number + " :: " + (me.getValue() == number));
			if (me.getValue().intValue() == number) {
				
				return true;
			}
		}
		
		return false;
	}
	
	public void listAllContacts() {
		Set<Entry<String, Integer>> set = contacts.entrySet();
		Iterator<Entry<String, Integer>> it = set.iterator();
		
		while (it.hasNext()) {
			Map.Entry<String, Integer> me = it.next();
			System.out.println(me);
		}

	}
}
public class Assignment3 {

	public static void main(String[] args) {
		ContactList contactsList = new ContactList();
		
		contactsList.addContact("Rupali", 98310983);
		contactsList.addContact("divya", 106788);
		contactsList.addContact("shruti", 9873452);
				
		System.out.println("Rupali: " + contactsList.doesContactNameExist("Rupali"));
		System.out.println("106788: " + contactsList.doesContactNumberExist(106788));
		
		System.out.println();
		contactsList.listAllContacts();
	}

}


------------output--------


C:\Users\rupali.gajakosh>cd desktop

C:\Users\rupali.gajakosh\Desktop>javac Assignment3.java

C:\Users\rupali.gajakosh\Desktop>java Assignment3
Rupali: true
106788: true

shruti=9873452
Rupali=98310983
divya=106788
