package com.yash.exception;

public class InputException extends Exception {
	public InputException() {
		super();
	}
	public InputException(String message) {
		super(message);
		
	}
	
}
