package com.yash.exception;

public class InpuFormatEcxeption extends Exception {

	public InpuFormatEcxeption() {
		super();
	}
	public InpuFormatEcxeption(String message) {
		super(message);
	}
}
