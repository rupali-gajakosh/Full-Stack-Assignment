package com.yash.service;

import com.yash.exception.DaoInputException;
import com.yash.exception.DaoOutputException;
import com.yash.exception.DataNotFound;
import com.yash.exception.InpuFormatEcxeption;

public interface InputInterface {

	void addMethod() throws InpuFormatEcxeption,DaoInputException;

	void displayAuthorDetails() throws DaoOutputException;

	void displayAuthor() throws DaoOutputException;

	void deleteBookByBookId()throws DataNotFound;

	void displyAllRecord() throws DaoOutputException;



	



}
