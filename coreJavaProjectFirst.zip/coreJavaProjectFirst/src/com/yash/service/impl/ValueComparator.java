package com.yash.service.impl;

import java.util.Comparator;
import java.util.Map;

public class ValueComparator implements Comparator<Integer> {
		    Map<Integer, String> base;

		    public ValueComparator(Map<Integer, String> map) {
		        this.base = map;
		    }

			public int compare(Integer o1, Integer o2) {
				if(base.get(o1).compareTo(base.get(o2))>1) {
					return 1;
				}
				else
				return -1;
			}
}
