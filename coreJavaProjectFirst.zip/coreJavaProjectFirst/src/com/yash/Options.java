package com.yash;

public class Options {

	public static void displayMenu() {
		System.out.println("=============MENU===============");
		System.out.println("1.Data insertion..");
		System.out.println("2.Display Books");
		System.out.println("3.Display Author");
		System.out.println("4.Delete book by particular id.");
		System.out.println("5.Sort books by book title");
		System.out.println("6.Exit");
		System.out.println("============================");
	}

	public static void exit() {
		System.out.println("Exit successful...");
		
	}

}
