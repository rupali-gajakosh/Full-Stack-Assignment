package com.yash.dao;

import java.sql.SQLException;

import java.util.List;
import java.util.Map;

import com.yash.entity.Author;
import com.yash.entity.Book;
import com.yash.exception.ConnectionUtilityException;
import com.yash.exception.DaoInputException;
import com.yash.exception.DaoOutputException;
import com.yash.exception.DataNotFound;

public interface AddRecord {

boolean addRecordOfBook(Book book)throws DaoInputException,ConnectionUtilityException;

List<Book> displayAuthorDao() throws DaoOutputException;

List<Author> displayAuthorDetailsDao()throws DaoOutputException;

boolean deleteBookDao(Book book)throws DataNotFound,SQLException;

Map<Integer, String> getAuthorData()throws DaoOutputException ;


}