package com.yash.springjdbcdemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;



import com.yash.springjdbc.dao.StudentDao;
import com.yash.springjdbc.entities.Student;



/**
* Hello world!
*
*/
public class App {
public static void main(String[] args) {
System.out.println("Hello World!");
ApplicationContext context = new ClassPathXmlApplicationContext("com/yash/springjdbcdemo/applicationcontext.xml");
StudentDao stdao = context.getBean("StudentDao", StudentDao.class);



Student s = new Student();
s.setId(1000);
s.setName("Rupali G");
//int r = stdao.insert(s);//insert

//System.out.println(r + "Student added Successfully ");
//int r = stdao.updatedetails(s);

//System.out.println(r + "Student updated successfully");

int r=stdao.deletedetails(1014826);//delete the details
System.out.println(r + "Student deleted Successfully ");
}
}